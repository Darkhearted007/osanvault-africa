#!/bin/bash
# -------------------------------
# ÒsánVault Africa: Full Deploy Script
# -------------------------------

# -------------------------------
# FTP CREDENTIALS
# -------------------------------
FTP_HOST="ftp.osanvaultafrica.com"
FTP_USER="olugbenga@osanvaultafrica.com"
FTP_PASS="_OQH47+hOtZ=W=Qb"
REMOTE_DIR="/public_html"

# -------------------------------
# SSH CREDENTIALS
# -------------------------------
SSH_HOST="osanvaultafrica.com"
SSH_USER="Olugbenga"
SSH_PASS="+&(~=t?CK,Xn7962"

# -------------------------------
# LOCAL ZIP FILE
# -------------------------------
ZIP_FILE="osanvault-africa.zip"

# -------------------------------
# Step 1: Zip project
# -------------------------------
echo "📦 Zipping project..."
zip -r $ZIP_FILE ./*

# -------------------------------
# Step 2: Upload via FTP (ignore SSL cert errors)
# -------------------------------
echo "🚀 Uploading ZIP to Truehost..."
lftp -u $FTP_USER,$FTP_PASS -e "set ssl:verify-certificate no; cd $REMOTE_DIR; put $ZIP_FILE; bye" $FTP_HOST

# -------------------------------
# Step 3: Extract via SSH
# -------------------------------
echo "⚡ Extracting ZIP on server..."
sshpass -p "$SSH_PASS" ssh -o StrictHostKeyChecking=no $SSH_USER@$SSH_HOST \
"cd $REMOTE_DIR && unzip -o $ZIP_FILE && rm -f $ZIP_FILE"

# -------------------------------
# Step 4: Completion message
# -------------------------------
echo "✅ Deployment complete!"
echo "🌐 Your site is live at https://osanvaultafrica.com"
